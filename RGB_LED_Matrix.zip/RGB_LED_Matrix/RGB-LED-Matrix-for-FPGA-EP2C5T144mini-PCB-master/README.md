# RGB-LED-Matrix-for-FPGA-EP2C5T144mini-PCB
5x5 RGB LED Matrix for FPGA EP2C5T144mini PCB

https://oshpark.com/profiles/Thyristor
